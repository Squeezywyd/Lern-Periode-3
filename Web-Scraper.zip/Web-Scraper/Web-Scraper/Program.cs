﻿using System;
using System.Net.Http;
using HtmlAgilityPack;
using static System.Net.WebRequestMethods;

class program
{
    static async System.Threading.Tasks.Task Main(string[] Arcs)
    {
        string url = "https://cartonal.ch/";       // <- Hier Websiten-URL einfügen!

        using (HttpClient client = new HttpClient())
        {
            string HtmlCode = await client.GetStringAsync(url);

            HtmlDocument HtmlDoc = new HtmlDocument();
            HtmlDoc.LoadHtml(HtmlCode);


            string xpathExpression = "//h1"; // Beispiel-XPath für h2-Titel 

            var TitleNodes = HtmlDoc.DocumentNode.SelectNodes(xpathExpression);

            if (TitleNodes != null)
            {
                foreach (var node in TitleNodes)
                {
                    Console.WriteLine("Titel:" + node.InnerText.Trim());

                }
            }

            else
            {
                Console.WriteLine("Keine passenden Elemente gefunden.");
            }
           


        }


    }
    
    
}   
